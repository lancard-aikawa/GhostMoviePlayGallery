# GhostMoviePlay の紹介

ツール自身の説明ページを操作しながら、3 段構成（plan → record → render）が何を分けているのかを見せる 1 本。

この zip は **その動画を撮った設定一式**です。動画は
https://lancard-aikawa.github.io/GhostMoviePlayGallery/v/gmp.html にあります。

## 出所

- リポジトリ: `GhostMoviePlay` の `docs/video/intro`
- コミット: `79aa111`
- 束ねた日: 2026-08-27

## 入っているもの

- `plan.json`
- `site/index.html`
- `video.md`

生成物 (ショット・音声・mp4) は入っていません。**手元で作れるもの**なので、
配るのは入力だけです。

## 置き場所

このフォルダは GhostMoviePlay の docs/video/intro/ に戻して使います —— app.start がこのパスの site/（収録対象の説明ページ。同梱してあります）を簡易サーバで配信するので、置き場所が変わると開けません。

## 使う

[GhostMoviePlay](https://github.com/lancard-aikawa/GhostMoviePlay) を入れてから:

```
uv run gmp ui --run          # 画面から。撮る面で段を上から押す
uv run gmp build plan.json --voice
```

## 走らせる前に読む

**`plan.json` の `app.setup` / `app.start` / `app.teardown` は、あなたの機械で
走るコマンドです。** 束を開いたら、まずそこを読んでください。この束のものは
撮影用のダミーを作って片付けるだけですが、**確かめるのは受け取った側の仕事**です。
