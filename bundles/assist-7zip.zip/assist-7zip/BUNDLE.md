# 7-Zip —— パスワード付き zip は、ファイル名を隠さない

機密ファイル 4 つを、いちばん強い AES-256 のパスワード付き zip にする。ところが出来た書庫を開くとパスワードを訊かれず、中のファイル名が全部読める。zip はファイル名の一覧を暗号化しない仕様で、暗号の強さとは関係が無いと説明し、7z 形式の「ファイル名を暗号化」で隠せるところまで。

この zip は **その動画を撮った設定一式**です。動画は
https://lancard-aikawa.github.io/GhostMoviePlayGallery/v/assist-7zip.html にあります。

## 出所

- リポジトリ: `GhostMoviePlay` の `docs/video/assist-7zip`
- コミット: `79aa111`
- 束ねた日: 2026-08-27

## 入っているもの

- `make_sample.py`
- `plan.json`
- `video.md`

生成物 (ショット・音声・mp4) は入っていません。**手元で作れるもの**なので、
配るのは入力だけです。

## 置き場所

どこに置いても動きます —— app.cwd はこのフォルダ自身で、仕込みが撮影用のダミーを作ります。撮るのは人なので gmp shoot から。

## 使う

[GhostMoviePlay](https://github.com/lancard-aikawa/GhostMoviePlay) を入れてから:

```
uv run gmp ui --run          # 画面から。撮る面で段を上から押す
uv run gmp build plan.json --voice
```

## 走らせる前に読む

**`plan.json` の `app.setup` / `app.start` / `app.teardown` は、あなたの機械で
走るコマンドです。** 束を開いたら、まずそこを読んでください。この束のものは
撮影用のダミーを作って片付けるだけですが、**確かめるのは受け取った側の仕事**です。
