# Krita —— 描けなくなったら、選択範囲を疑う

図形の片方を矩形選択して塗ったあと、解除を忘れたまま別の場所へ筆を走らせると、なぞっても線が一本も残らない。エラーも音も出ないのでブラシやレイヤーを疑ってしまうが、原因は離れたところに残った選択範囲で、その外側は描けないように保護されている。解除して同じブラシ・同じ場所に描けるところまで。

この zip は **その動画を撮った設定一式**です。動画は
https://lancard-aikawa.github.io/GhostMoviePlayGallery/v/assist-krita.html にあります。

## 出所

- リポジトリ: `GhostMoviePlay` の `docs/video/assist-krita`
- コミット: `02fe6b1`
- 束ねた日: 2026-08-27

## 入っているもの

- `make_sample.py`
- `plan.json`
- `video.md`

生成物 (ショット・音声・mp4) は入っていません。**手元で作れるもの**なので、
配るのは入力だけです。

## 置き場所

どこに置いても動きます —— app.cwd はこのフォルダ自身で、仕込みが撮影用のダミーを作ります。撮るのは人なので gmp shoot から。

## 使う

[GhostMoviePlay](https://github.com/lancard-aikawa/GhostMoviePlay) を入れてから:

```
uv run gmp doctor            # 足りない前提を言う
uv run gmp ui --run          # 画面から。撮る面で段を上から押す
uv run gmp build plan.json --voice
```

**手引きは [README_BUNDLE.md](https://github.com/lancard-aikawa/GhostMoviePlay/blob/main/README_BUNDLE.md)。**
落としてから撮るまでを Claude Code にやらせる頼み方も、そこに貼れる形で置いてあります。

## 走らせる前に読む

**`plan.json` の `app.setup` / `app.start` / `app.teardown` は、あなたの機械で
走るコマンドです。** 束を開いたら、まずそこを読んでください。この束のものは
撮影用のダミーを作って片付けるだけですが、**確かめるのは受け取った側の仕事**です。
