# GlossPop —— 登録する語は「短いほど危ない」

選択したテキストを AI が辞書化して以後の表示で自動リンクするビューア。短く一般的な語を登録すると本文がリンクだらけになるところを実演し、日本語には語境界が無く部分文字列で照合しているからだと説明して、用語名を直して 1 箇所に収めるまで。

この zip は **その動画を撮った設定一式**です。動画は
https://lancard-aikawa.github.io/GhostMoviePlayGallery/v/glosspop.html にあります。

## 出所

- リポジトリ: `GlossPop` の `docs/video/gloss-scope`
- コミット: `12d1f33`
- 束ねた日: 2026-08-27

## 入っているもの

- `plan.json`
- `serve.py`
- `video.md`

生成物 (ショット・音声・mp4) は入っていません。**手元で作れるもの**なので、
配るのは入力だけです。

## 置き場所

このフォルダは GlossPop の docs/video/gloss-scope/ に戻して使います —— app.cwd が GlossPop のルートを指していて、serve.py が向こうの content/ を読みます。撮る対象そのものは入っていません（別リポジトリです）。

## 使う

[GhostMoviePlay](https://github.com/lancard-aikawa/GhostMoviePlay) を入れてから:

```
uv run gmp ui --run          # 画面から。撮る面で段を上から押す
uv run gmp build plan.json --voice
```

## 走らせる前に読む

**`plan.json` の `app.setup` / `app.start` / `app.teardown` は、あなたの機械で
走るコマンドです。** 束を開いたら、まずそこを読んでください。この束のものは
撮影用のダミーを作って片付けるだけですが、**確かめるのは受け取った側の仕事**です。
